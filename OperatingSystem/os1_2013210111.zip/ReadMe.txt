2013210111 Nam SeHyun

1. Folder 1st_assign 	: copy to (kernel)/
2. Makefile		: copy to (kernel)/
3. syscall_table_32.S	: copy to (kernel)/arch/x86/kernel/
4. unistd_32.h		: copy to (kernel)/arch/x86/include/asm/
5. syscall.h		: copy to (kernel)/include/linux/

6. call_queue.cpp	: compile with g++.

after compile and make execution program, press "E" or "D" for Enqueue or Dequeue.
